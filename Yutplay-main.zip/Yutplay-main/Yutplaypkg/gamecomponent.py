# gamecomponent.py

class GameComponent:
    def __init__(self, verbose=False):
        self.verbose = verbose